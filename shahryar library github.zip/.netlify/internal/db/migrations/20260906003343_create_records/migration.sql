CREATE TABLE "records" (
	"id" serial PRIMARY KEY,
	"slug" text NOT NULL UNIQUE,
	"title_fa" text NOT NULL,
	"title_en" text NOT NULL,
	"cover_title_fa" text NOT NULL,
	"cover_title_en" text NOT NULL,
	"author_fa" text NOT NULL,
	"author_en" text NOT NULL,
	"summary_fa" text DEFAULT '' NOT NULL,
	"summary_en" text DEFAULT '' NOT NULL,
	"categories" text[] DEFAULT '{}'::text[] NOT NULL,
	"material_type" text NOT NULL,
	"date_label" text DEFAULT '' NOT NULL,
	"sort_year" integer,
	"work_language" text DEFAULT '' NOT NULL,
	"publisher_fa" text DEFAULT '' NOT NULL,
	"publisher_en" text DEFAULT '' NOT NULL,
	"icon" text DEFAULT '📖' NOT NULL,
	"source_url" text,
	"featured" boolean DEFAULT false NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE INDEX "records_material_type_idx" ON "records" ("material_type");--> statement-breakpoint
CREATE INDEX "records_sort_year_idx" ON "records" ("sort_year");